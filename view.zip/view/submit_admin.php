<?php
$adminNameErr = $adminEmailErr = $adminPasswordErr = $reportDateErr = $adminImageErr = "";
$admin_name = $admin_email = $admin_password = $metro_line = $report_date = $uploadedImagePath = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (empty($_POST["admin_name"])) {
        $adminNameErr = "Admin name is required";
    } else {
        $admin_name = test_input($_POST["admin_name"]);
        if (!preg_match("/^[a-zA-Z-' ]*$/", $admin_name)) {
            $adminNameErr = "Only letters and white space allowed";
        }
    }

    if (empty($_POST["admin_email"])) {
        $adminEmailErr = "Admin email is required";
    } else {
        $admin_email = test_input($_POST["admin_email"]);
        if (!filter_var($admin_email, FILTER_VALIDATE_EMAIL)) {
            $adminEmailErr = "Invalid email format";
        }
    }

    if (empty($_POST["admin_password"])) {
        $adminPasswordErr = "Password is required";
    } else {
        $admin_password = test_input($_POST["admin_password"]);
        if (strlen($admin_password) < 6) {
            $adminPasswordErr = "Password must be at least 6 characters";
        }
    }

    $metro_line = isset($_POST["metro_line"]) ? test_input($_POST["metro_line"]) : "";

    if (empty($_POST["report_date"])) {
        $reportDateErr = "Report date is required";
    } else {
        $report_date = test_input($_POST["report_date"]);
    }

    if (isset($_FILES["admin_image"]) && $_FILES["admin_image"]["error"] == 0) {
        $allowedTypes = ['image/jpeg', 'image/png', 'image/jpg', 'image/webp'];
        $fileType = $_FILES["admin_image"]["type"];
        $fileSize = $_FILES["admin_image"]["size"];

        if (!in_array($fileType, $allowedTypes)) {
            $adminImageErr = "Only JPG, JPEG, PNG, or WEBP files are allowed.";
        } elseif ($fileSize > 2 * 1024 * 1024) {
            $adminImageErr = "File size must be less than 2MB.";
        } else {
            $uploadDir = "uploads/";
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0755, true);
            }
            $uploadedImagePath = $uploadDir . basename($_FILES["admin_image"]["name"]);
            if (!move_uploaded_file($_FILES["admin_image"]["tmp_name"], $uploadedImagePath)) {
                $adminImageErr = "Failed to upload image.";
            }
        }
    } else {
        $adminImageErr = "Profile picture is required.";
    }
}

function test_input($data) {
    return htmlspecialchars(stripslashes(trim($data)));
}
?>